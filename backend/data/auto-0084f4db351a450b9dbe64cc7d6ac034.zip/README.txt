LoomLab production package
==========================

Inks (3): 1. Ink 1 (#F4ECD8), 2. Ink 3 (#8A1C1C), 3. Ink 2 (#1B3A6B)

Print size: 8.00 x 5.33 in at 300 DPI (enlarged from 1200 x 800 px, edges redrawn smooth)
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
