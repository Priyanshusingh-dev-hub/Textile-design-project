LoomLab production package
==========================

Inks (8): 1. Ink 6 (#F9F8F5), 2. Ink 5 (#E1C9A2), 3. Ink 3 (#F25497), 4. Ink 4 (#AB7944), 5. Ink 2 (#F92F2E), 6. Ink 8 (#CF6123), 7. Ink 1 (#DE1464), 8. Ink 7 (#214440)

Print size: 4.83 x 3.62 in at 300 DPI
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
