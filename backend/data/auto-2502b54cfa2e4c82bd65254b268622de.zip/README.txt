LoomLab production package
==========================

Inks (14): 1. Ink 3 (#C7D458), 2. Ink 4 (#6BD6A6), 3. Ink 12 (#2CD2DA), 4. Ink 10 (#9EAB7B), 5. Ink 9 (#40ABC9), 6. Ink 8 (#D48B4E), 7. Ink 13 (#2395E1), 8. Ink 11 (#987880), 9. Ink 14 (#6772A8), 10. Ink 2 (#D3354E), 11. Ink 6 (#2B67DB), 12. Ink 7 (#A12D78), 13. Ink 5 (#722BA0), 14. Ink 1 (#2A26DB)

Print size: 1.33 x 1.00 in at 300 DPI
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
