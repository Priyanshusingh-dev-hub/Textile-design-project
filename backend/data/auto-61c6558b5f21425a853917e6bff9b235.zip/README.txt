LoomLab production package
==========================

Inks (5): 1. Ink 2 (#EAE8E2), 2. Ink 3 (#C3BDB2), 3. Ink 4 (#524837), 4. Ink 1 (#332B1C), 5. Ink 5 (#1F170C)

Print size: 4.83 x 3.62 in at 300 DPI
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
