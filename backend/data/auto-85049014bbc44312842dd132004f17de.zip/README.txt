LoomLab production package
==========================

Inks (9): 1. Ink 2 (#DDEBED), 2. Ink 3 (#27BBC6), 3. Ink 5 (#509DCA), 4. Ink 4 (#738A56), 5. Ink 7 (#0A8F92), 6. Ink 6 (#056978), 7. Ink 9 (#A43857), 8. Ink 8 (#4A5930), 9. Ink 1 (#014162)

Print size: 4.83 x 3.62 in at 300 DPI
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
