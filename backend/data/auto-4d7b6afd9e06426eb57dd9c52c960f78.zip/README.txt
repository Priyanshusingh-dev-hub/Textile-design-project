LoomLab production package
==========================

Inks (7): 1. Ink 1 (#E1D2BB), 2. Ink 6 (#F4B1B3), 3. Ink 7 (#F28DA8), 4. Ink 4 (#737650), 5. Ink 5 (#CB3D5B), 6. Ink 2 (#68563C), 7. Ink 3 (#3C4B28)

Print size: 30.00 x 22.50 in at 300 DPI (enlarged from 1448 x 1086 px, edges redrawn smooth)
Cloth: #FFFFFF
Inks are listed lightest first: a dark ink printed early dirties the lighter ones after it.

plates/   colour proof of each ink on the cloth colour (PNG)
screens/  print-ready B&W separations, black = ink (TIFF, 300 DPI, with registration marks in the margin)
proof.png full-colour composite of all inks
job-sheet.png  one page to print and pin up at the press: screens in order,
               ink colours, coverage, print size and cloth

Print one screen per ink. The registration targets in every screen
share the same position, so the screens line up when superimposed.
